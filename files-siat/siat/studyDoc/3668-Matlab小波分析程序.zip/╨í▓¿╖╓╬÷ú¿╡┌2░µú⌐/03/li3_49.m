clear all;
load leleccum;
s=leleccum(1:1000);
w='db2';
lx=length(s);
subplot(2,2,1);plot(s);
title('ԭʼ�ź�');
dwtmode;
[cap,cdp]=dwt(s,w);
lxt=2*length(cap);
xzd=idwt(cap,cdp,w,lx);        %���źŽ����ع�
subplot(2,2,2);plot(xzd);
title('zpdģʽ�ع�ͼ');
dwtmode('sym');
[cam,cdm]=dwt(s,w);
lxm=2*length(cam);
xsm=idwt(cam,cdm,w,lx);    %�ź��ع�
subplot(2,2,3);plot(xsm);
title('symģʽ�ع�ͼ');
dwtmode('ppd');
[cad,cdd]=dwt(s,w);
lxd=2*length(cad);
xsd=idwt(cad,cdd,w,lx);
subplot(2,2,4);plot(xsd);
title('ppdģʽ�ع�ͼ');
