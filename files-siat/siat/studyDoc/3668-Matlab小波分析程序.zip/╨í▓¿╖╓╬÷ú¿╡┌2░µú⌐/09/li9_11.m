 clear all;
[wfun,xg]=wpfun('haar',7,5);       %n=0,1,...,7
figure;
for i=1:8
    w=wfun(i,:);
    subplot(4,2,i);plot(w);
    ylabel(['W',num2str(i)]);
end
[wfun2,xg2]=wpfun('db2',7,5);       %n=0,1,...,7
figure;
for i=1:8
    w2=wfun2(i,:);
    subplot(4,2,i);plot(w2);
    ylabel(['W',num2str(i)]);
end
