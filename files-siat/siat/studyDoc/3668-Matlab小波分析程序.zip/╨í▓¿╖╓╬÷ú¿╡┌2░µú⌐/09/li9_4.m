 clear all;
x=linspace(0,10,1000);
y=25*exp(-(x-5.7).^2/(2*0.5*2))+20*exp(-(x-3.6).^2/(2*0.2^2))-3*x+10;     %ɫ��ģ��
[c,l]=wavedec(y,7,'db3');
a7=wrcoef('a',c,l,'db3',7);
a6=wrcoef('a',c,l,'db3',6);
a5=wrcoef('a',c,l,'db3',5);
a4=wrcoef('a',c,l,'db3',4);
a3=wrcoef('a',c,l,'db3',3);
figure;
plot(x,y);
xlabel('ʱ��');ylabel('��ֵ');
axis([0 10 0 25])
figure;
plot(a3-a7)          
xlabel('ʱ��');ylabel('��ֵ');
