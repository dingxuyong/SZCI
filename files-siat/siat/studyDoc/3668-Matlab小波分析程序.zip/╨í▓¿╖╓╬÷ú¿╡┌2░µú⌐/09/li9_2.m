 clear all;
x=[0.1219 0.2138 0.3217 0.4234 0.5364 0.8354 1.4327 1.8674 1.6040...
 0.9217 0.5328 0.5879 0.5971 0.3904];
t=(410:10:540);
[c,l]=wavedec(x,5,'db3');            %С���ֽ�
d5=wrcoef('d',c,l,'db3',5);          %�ع���1~5��ϸ��ϵ��
d4=wrcoef('d',c,l,'db3',4); 
d3=wrcoef('d',c,l,'db3',3); 
d2=wrcoef('d',c,l,'db3',2); 
d1=wrcoef('d',c,l,'db3',1); 
figure;plot(t,x);
xlabel('����/nm');ylabel('����ֵ');
figure;
subplot(5,1,1);plot(d5);
ylabel('d5');
subplot(5,1,2);plot(d4);
ylabel('d4')
subplot(5,1,3);plot(d3);
ylabel('d3')
ylabel('d3');
subplot(5,1,4);plot(d2);
ylabel('d2')
subplot(5,1,5);plot(d1);
ylabel('d1');xlabel('����/nm');
