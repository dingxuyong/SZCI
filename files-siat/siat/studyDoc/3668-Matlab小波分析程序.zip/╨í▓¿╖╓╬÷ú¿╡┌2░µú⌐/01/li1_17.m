 clear all;
x=0:0.25:10;
stairs(x,sin(x));
x=-2:0.1:2;
y=erf(x);
e = rand(size(x))/10; 
errorbar(x,y,e);
