 clear all;
% ����ֵ
lambda = [9.6397238445, 15.19725192, 2*pi^2, ...
    29.5214811, 31.9126360, 41.4745099, 44.948488, ...
    5*pi^2, 5*pi^2, 56.709610, 65.376535, 71.057755];
% ��������
for k = 1:12
   L{k} = membrane(k);
end
% ����������ϵ��
for k = 1:12
    c(k) = L{k}(25,23)/3;
end
fig = figure;
set(fig,'color','k')
x = (-15:15)/15;
h = surf(x,x,L{1});
[a,e] = view; view(a+270,e);
axis([-1 1 -1 1 -1 1]);
caxis(26.9*[-1.5 1]);
colormap(hot);
axis off
t = 0;
dt = 0.025;
set(fig,'userdata',dt)
while ishandle(fig)
    % ϵ��
    dt = get(fig,'userdata');
    t = t + dt;
    s = c.*sin(sqrt(lambda)*t);
    % ���
    A = zeros(size(L{1}));
    for k = 1:12
      A = A + s(k)*L{k};
    end
    % �ٶ�
    s = lambda .*s;
    V = zeros(size(L{1}));
    for k = 1:12
      V = V + s(k)*L{k};
    end
    V(16:31,1:15) = NaN;
    % ���ߵĸ߶ȣ��Բ�ɫ�����ٶ�
    set(h,'zdata',A,'cdata',V);
    drawnow
end;
